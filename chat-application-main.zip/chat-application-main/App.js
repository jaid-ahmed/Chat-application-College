import React from 'react'
import ChatRoom from './component/ChatRoom'

// import "./App.css";

 const App = () => {
  // const myStyle={
  //   backgroundImage:"url(${process.env.PUBLIC_URL + '/bg image.jpg'}"
  // }
 
  
  return (
    <ChatRoom />
  )
}

export default App