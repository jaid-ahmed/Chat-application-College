package com.involveininnovation.chatsever;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatseverApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatseverApplication.class, args);
	}

}
