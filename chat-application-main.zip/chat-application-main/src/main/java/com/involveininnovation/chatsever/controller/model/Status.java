package com.involveininnovation.chatsever.controller.model;

public enum Status {
    JOIN,
    MESSAGE,
    LEAVE
}
