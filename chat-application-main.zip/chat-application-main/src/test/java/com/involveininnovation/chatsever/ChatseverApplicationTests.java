package com.involveininnovation.chatsever;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatseverApplicationTests {

	@Test
	void contextLoads() {
	}

}
